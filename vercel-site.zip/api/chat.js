// CUBE backend on Vercel. The Gemini key lives in the GEMINI_API_KEY environment variable, never in the browser.
module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Use POST' });
  const key = process.env.GEMINI_API_KEY;
  if (!key) return res.status(500).json({ error: 'The server is missing GEMINI_API_KEY.' });

  let body = req.body;
  if (typeof body === 'string') { try { body = JSON.parse(body); } catch (e) { body = null; } }
  const msgs = body && Array.isArray(body.messages) ? body.messages.slice(-30) : [];
  if (!msgs.length) return res.status(400).json({ error: 'No messages' });

  const contents = msgs.map(m => ({
    role: m.role === 'assistant' ? 'model' : 'user',
    parts: [{ text: String(m.content).slice(0, 100000) }],
  }));
  for (const d of (body.images || []).slice(0, 4)) {
    const m = /^data:(image\/[a-z+.-]+);base64,(.+)$/i.exec(d);
    if (m) contents[contents.length - 1].parts.push({ inlineData: { mimeType: m[1], data: m[2] } });
  }

  const model = process.env.GEMINI_MODEL || 'gemini-flash-latest'; // change with the GEMINI_MODEL variable
  try {
    const r = await fetch('https://generativelanguage.googleapis.com/v1beta/models/' + model + ':generateContent', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-goog-api-key': key },
      body: JSON.stringify({ contents, generationConfig: { maxOutputTokens: 4096 } }),
    });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) {
      return res.status(r.status === 429 ? 429 : 502).json({
        error: r.status === 429 ? 'The free AI quota is used up for now. Try again in a minute, or tomorrow.' : (d.error && d.error.message) || 'AI error',
      });
    }
    const parts = (d.candidates && d.candidates[0] && d.candidates[0].content && d.candidates[0].content.parts) || [];
    const text = parts.map(p => p.text || '').join('');
    return res.status(200).json({ text: text || '(No answer was returned. Try rephrasing.)' });
  } catch (e) {
    return res.status(502).json({ error: 'Could not reach the AI service.' });
  }
};
