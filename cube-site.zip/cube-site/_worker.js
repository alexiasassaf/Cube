// CUBE backend: serves the website and talks to Gemini. The API key stays here, never in the browser.
const json = (o, s = 200) => new Response(JSON.stringify(o), { status: s, headers: { 'Content-Type': 'application/json' } });

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname !== '/api/chat') return env.ASSETS.fetch(request); // everything else = the website
    if (request.method !== 'POST') return json({ error: 'Use POST' }, 405);
    if (!env.GEMINI_API_KEY) return json({ error: 'The server is missing GEMINI_API_KEY.' }, 500);

    let body;
    try { body = await request.json(); } catch { return json({ error: 'Bad request' }, 400); }
    const msgs = Array.isArray(body.messages) ? body.messages.slice(-30) : [];
    if (!msgs.length) return json({ error: 'No messages' }, 400);

    const contents = msgs.map(m => ({
      role: m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: String(m.content).slice(0, 100000) }],
    }));
    for (const d of (body.images || []).slice(0, 4)) {
      const m = /^data:(image\/[a-z+.-]+);base64,(.+)$/i.exec(d);
      if (m) contents[contents.length - 1].parts.push({ inlineData: { mimeType: m[1], data: m[2] } });
    }

    const model = env.GEMINI_MODEL || 'gemini-flash-latest'; // change via the GEMINI_MODEL variable
    const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-goog-api-key': env.GEMINI_API_KEY },
      body: JSON.stringify({ contents, generationConfig: { maxOutputTokens: 4096 } }),
    });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) {
      return json({ error: r.status === 429 ? 'The free AI quota is used up for now. Try again in a minute, or tomorrow.' : (d.error && d.error.message) || 'AI error' }, r.status === 429 ? 429 : 502);
    }
    const text = ((d.candidates && d.candidates[0] && d.candidates[0].content && d.candidates[0].content.parts) || []).map(p => p.text || '').join('');
    return json({ text: text || '(No answer was returned. Try rephrasing.)' });
  },
};
